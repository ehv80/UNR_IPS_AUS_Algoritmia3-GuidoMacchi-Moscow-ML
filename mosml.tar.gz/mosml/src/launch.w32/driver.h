#define eq !strcmp

int suffix(char *, char *);
char* woSuffix(char* name);
int prefix(char *, char *);
char* xmalloc(int size);
void format(char **, char *, ...);
void reformat(char **, char *, ...);

