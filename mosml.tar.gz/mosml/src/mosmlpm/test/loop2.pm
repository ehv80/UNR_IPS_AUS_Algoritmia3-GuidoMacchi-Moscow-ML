import loop1.pm
in
   structure A.sml
end
