#ifndef _str_
#define _str_


#include "misc.h"

EXTERN mlsize_t string_length (value);
EXTERN value compare_strings (value, value);


#endif /* _str_ */
