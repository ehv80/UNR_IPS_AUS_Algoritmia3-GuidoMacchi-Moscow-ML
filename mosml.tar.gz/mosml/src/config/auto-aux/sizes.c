int main(argc, argv)
     int argc;
     char ** argv;
{
  printf("%d %d %d\n", sizeof(int), sizeof(long), sizeof(long *));
  return 0;
}
