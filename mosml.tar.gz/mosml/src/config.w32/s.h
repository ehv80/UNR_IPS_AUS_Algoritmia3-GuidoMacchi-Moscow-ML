#define HAS_MEMMOVE
#define HAS_BCOPY
#define sighandler_return_type void
/* #define BSD_SIGNALS */
#define HAS_RENAME
/* #define HAS_UTIMES */
#define HAS_DUP2
#define HAS_SELECT
/* #define HAS_SYMLINK */
/* #define HAS_WAITPID */
#define HAS__SETJMP
