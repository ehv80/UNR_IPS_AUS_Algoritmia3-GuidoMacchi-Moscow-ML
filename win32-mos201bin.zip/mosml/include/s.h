#define HAS_MEMMOVE
#define HAS_BCOPY
#define HAS__SETJMP
#define sighandler_return_type void
#define BSD_SIGNALS
#define HAS_RENAME
#define HAS_STRERROR
#define HAS_SOCKETS
#define HAS_UTIMES
#define HAS_DUP2
#define HAS_TRUNCATE
#define HAS_SELECT
#define HAS_SYMLINK
#define HAS_WAIT3
#define HAS_WAITPID
