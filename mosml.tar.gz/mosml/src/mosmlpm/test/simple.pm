(*structure A.sig*)
structure A.sml
B-sig.sml
B.sml
(*toplevel D.sig*)
toplevel D.sml
C.sml
