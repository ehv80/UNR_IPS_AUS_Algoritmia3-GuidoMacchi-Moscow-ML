main() {
  tcgetattr();
  tcsetattr();
  tcsendbreak();
  tcflush();
  tcflow();
}
